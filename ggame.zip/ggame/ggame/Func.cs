﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace ggame
{
    class Func
    {
        public static void MooveFunc(Rectangle[,] pole, int plsMns, int plsMns2, int i, int a, string[,] poleCond)//метод для движения героя(t2 - массив плиток(tabl), plsMns - это насколько мы передвигаемся по плиткам стролбцам , plsMns2 - это насколько мы передвигаемся по плиткам строкам
        {

            DrawFunc(MainWindow.myIconSource, pole[i, a]);//функция рисования              
            if(poleCond[i - plsMns, a - plsMns2] != "stump" && poleCond[i - plsMns, a - plsMns2] != "kremen")//если состояние этой плитки не равно "пень"
            {
               pole[i - plsMns , a - plsMns2].Fill = new SolidColorBrush(Colors.White);//закрашиваем прошлую плитку  
            }
            else//иначе
            {
                if (poleCond[i - plsMns, a - plsMns2] == "stump")
                {
                    DrawFunc(new Uri(@"C:\Users\Leon\Desktop\programmDraws\pen.PNG"), pole[i - plsMns, a - plsMns2]);//мы не закрашиваем эту плитку белым, а красим в картинку пня
                }
                else
                {

                    DrawFunc(new Uri(@"C:\Users\Leon\Desktop\programmDraws\Kremen.PNG"), pole[i - plsMns, a - plsMns2]);
                }
               
            }                                                           
        }
        public static void DrawFunc(Uri sourceOfDraw, Rectangle rect)//функция рисования
        {
            ImageBrush imgBrush = new ImageBrush                   //
            {                                                      //
                ImageSource = new BitmapImage(sourceOfDraw)        //красим заданную плитку в нужную картинку
            };                                                     //                                                                      
            rect.Fill = imgBrush;                                    //функция усталости
        }
        public static void fatigueFunc(ProgressBar fatigue, ProgressBar golod, ProgressBar jajda, ProgressBar radio, ProgressBar hp)//функция усталости
        {
            fatigue.Value = Convert.ToInt32(fatigue.Value) + 2;//прибавляем усталость
            golod.Value = Convert.ToInt32(golod.Value) + 2;//прибавляем усталость
            jajda.Value = Convert.ToInt32(jajda.Value) + 2;//прибавляем усталость
            radio.Value = Convert.ToInt32(radio.Value) + 2;//прибавляем усталость
            if (fatigue.Value == 100)
            {
                golod.Value += 2;
                fatigue.Value -= 5;
                jajda.Value -= 2;
                radio.Value += 2;
                hp.Value--;
            }
            if (golod.Value == 100 || jajda.Value == 100)
            {
                hp.Value -= 2;
            }
            if (radio.Value == 100)
            {
                hp.Value -= 5;
            }
            if(hp.Value == 0)
            {
                Environment.Exit(0);
            }
        }
        public static int InvFunc(int indOfNullcnd, string[] invcnd, string[,] tablCondition, int[] nowSide, int pls, int pls2, string txt, Uri source, ProgressBar fatigue, Rectangle[] inv, string newCond, ProgressBar golod, ProgressBar jajda, ProgressBar rad, ProgressBar hp)//функция заполнения инвентаря
        {
            Random rnd = new Random();//новый рандом
            if (rnd.Next(0, 7) == 3 && indOfNullcnd != invcnd.Length && tablCondition[nowSide[0] -pls, nowSide[1] - pls2] == txt)//если рандом равен 3 и это не плитка за границей инвентаря и герой ищет у заданного объекта
            {
                DrawFunc(source, inv[indOfNullcnd]);                               //функция рисования
                File.WriteAllText(@"C:\Users\Leon\Desktop\cond.txt", "");      //очищаем файл, в котором записывается состояние
                File.WriteAllText(@"C:\Users\Leon\Desktop\cond.txt", newCond); //записываем состояние(так мы возвращаем второе значение)
                fatigueFunc(fatigue, golod, jajda, rad, hp);                                //функция усталости
                indOfNullcnd++;                                                //следующая свободная ячейка инвенторя
                File.WriteAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt", "");//очищаем файл
                File.WriteAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt", Convert.ToString(indOfNullcnd));//записываем новый индекс пустой плитки
            }
            return indOfNullcnd;
        }
        public static string FillFunc(int i, int a, int[] nowSide, Rectangle[,] tabl, string[,] condition, Uri source,string cond)//функция заполнения поля
        {
            if (i != nowSide[0] || a != nowSide[1])    //если эта плитка не равна плитке, на которой находится герой(чтобы не поставить дерево вместо героя) 
            {        
                ImageBrush imgBrush = new ImageBrush  //
                {                                     //
                    ImageSource = new BitmapImage(source) //картинка плитки равна чему-то
                };                                    //
                tabl[i, a].Fill = imgBrush;           //
                condition[i, a] = cond;               //состояние этой плитки в массиве соndition равно чему-то
            }                                         //
            return condition[i, a];                   //возвращаем состояние этой плитки
        }
        public static int CreateFunc(Rectangle[] inv, int indexOfNullCnd, Rectangle[] invc)//функция смещения(чтобы в инвентаре не было пустых ячеек)
        {
            for (int i = 0; i < inv.Length; i++)//бежим по плиткам
            {                        
                if (invc[i].Fill == new SolidColorBrush(Colors.White))//находи первую пустую плитку                   
                {
                    indexOfNullCnd = i;//задаём следующую пустую ячейку                
                    i = inv.Length;//выходим из цикла                                     
                }                                   
            }
            return indexOfNullCnd - 1;//возращаем
        }
        public static string[] CreateFunc2(Rectangle[] inv, string[] invcond)
        {
            for (int i = 0; i < inv.Length; i++)
            {
                for (int a = 0; a < 5; a++)
                {
                    if (i != inv.Length - 1)//если эта не последняя плитка
                    {
                        if (invcond[i] == "" && invcond[i + 1] != "")//если эта плитка пустая, а следующая нет
                        {
                            invcond[i] = invcond[i + 1];   //меняем местами состояние плиток
                            invcond[i + 1] = "";           //
                            inv[i].Fill = inv[i + 1].Fill;                       //меняем картинки плиток
                            inv[i + 1].Fill = new SolidColorBrush(Colors.White);   //
                        }
                    }
                }
               
            }
            return invcond;
        }
        public static void RubFuncIn(Rectangle penRectangle, ProgressBar fatigue, int cooX, int cooY, string[,] condPole, int geroyCooX, int geroyCooY, Rectangle[,] pen)
        {
            try
            {
                if (condPole[geroyCooX, geroyCooY] == "tree")
                {
                    if (pen[geroyCooX, geroyCooY] == penRectangle)
                    {
                        DrawFunc(new Uri(@"C:\Users\Leon\Desktop\programmDraws\pen.PNG"), penRectangle);//функция рисования
                        condPole[cooX, cooY] = "stump";
                    }
                }
            }
            catch (Exception)
            {       
            }
            
        }
        public static string[] FuncOfPoleSerch(int X, int Y, int[] nowSide, string txt, string txt2, string[,] condPole, Rectangle[,] pole, Rectangle clickRect, int nullIndex, string[] invCond, Rectangle[] inv, Uri source)
        {
            try
            {
              
                if (condPole[X, Y] == "kremen")
                {
                    if (pole[X, Y] == clickRect)
                    {
                        invCond[nullIndex] = txt2;
                        DrawFunc(new Uri(@"C:\Users\Leon\Desktop\programmDraws\smallKremen.PNG"), MainWindow.inventory[nullIndex]);
                        if(nullIndex != inv.Length)
                        {
                            nullIndex++;
                            File.WriteAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt", Convert.ToString(nullIndex));
                        }

                    }
                }
            }
            catch (Exception)
            {
            }
            return invCond;
        }
        public static void RubFunc(string[] invcnd, Rectangle penRectangle, ProgressBar fatigue, int cooX, int cooY, string[,] condPole, int geroyCooX, int geroyCooY, Rectangle[,] pole)//функция рубки деревьев
        {
            for (int b = 0; b < 3; b++)//бежим по ячейкам
            {
                if (invcnd[b] == "simpleTopor")//если в инвентаре есть топор, а на этой плитке находится дерево
                {

                    RubFuncIn(penRectangle, fatigue, cooX, cooY, condPole, geroyCooX + 1, geroyCooY, pole);
                    RubFuncIn(penRectangle, fatigue, cooX, cooY, condPole, geroyCooX, geroyCooY + 1, pole);
                    RubFuncIn(penRectangle, fatigue, cooX, cooY, condPole, geroyCooX - 1, geroyCooY, pole);
                    RubFuncIn(penRectangle, fatigue, cooX, cooY, condPole, geroyCooX, geroyCooY - 1, pole);
                }
            }

            
        }
        public static string[] InvClick(string[] inventoryCondition, int num, Rectangle r, Rectangle[] inventory, int indexOfNullInventory, ProgressBar jajda, ProgressBar golod, ProgressBar rad, ProgressBar hp)
        {
            if (inventoryCondition[num] == "water")
            {
                inventoryCondition[num] = "";
                r.Fill = new SolidColorBrush(Colors.White);
                inventoryCondition = CreateFunc2(inventory, inventoryCondition);
                indexOfNullInventory = CreateFunc(inventory, indexOfNullInventory, inventory);
                jajda.Value -= 10;
                rad.Value -= 3;

            }
            if (inventoryCondition[num] == "yabloko")
            {
                inventoryCondition[num] = "";
                r.Fill = new SolidColorBrush(Colors.White);
                inventoryCondition = CreateFunc2(inventory, inventoryCondition);
                indexOfNullInventory = CreateFunc(inventory, indexOfNullInventory, inventory);
                golod.Value -= 10;
                hp.Value++;

            }
            File.WriteAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt", "");
            File.WriteAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt", Convert.ToString(indexOfNullInventory));
            return inventoryCondition;
        }
        public static string[] InvDelete(string[] inventoryCondition, int num, Rectangle r, Rectangle[] inventory, int indexOfNullInventory)
        {
            inventoryCondition[num] = "";
            r.Fill = new SolidColorBrush(Colors.White);
            inventoryCondition = CreateFunc2(inventory, inventoryCondition);
            indexOfNullInventory = CreateFunc(inventory, indexOfNullInventory, inventory);
            File.WriteAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt", "");
            File.WriteAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt", Convert.ToString(indexOfNullInventory));
            return inventoryCondition;
        }
    }
}
