﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace ggame
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            
            InitializeComponent();
            l1.Content = "введите ПОЛНЫЙ путь к картинке, рекомендуется квадратная картинка,\n иначе изображение будет отображаться неправильно.";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(txt.Text != "")
                {
                    MainWindow.myIconSource = new Uri(txt.Text);              
                    File.WriteAllText(@"C:\Users\Leon\source\repos\ggame\ggame\MyIconSource.txt", txt.Text);
                    Close();
                }

            }
            catch (Exception)
            {

                MessageBox.Show("возникла ошибка, провертье правильность адресса.","Error",MessageBoxButton.OK, MessageBoxImage.Error);
                Close();
            }
        }
    }
}
