﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ggame
{
    /// <summary>
    /// Логика взаимодействия для create.xaml
    /// </summary>
    public partial class create : Window
    {
        public create()
        {
            InitializeComponent();
        }
        int[] elements = new int[4];
        int[] IndexOfelements = new int[4];


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            for(int i = 0; i < MainWindow.inventoryCondition.Length; i++)
            {
                if(MainWindow.inventoryCondition[i] == "stick")
                {
                    elements[0]++;
                    IndexOfelements[0] = i;
                }
                if (MainWindow.inventoryCondition[i] == "smallRock")
                {
                    elements[1]++;
                    IndexOfelements[1] = i;
                }
                if(elements[0] >= 1 && elements[1] >= 1)
                {
                    MainWindow.inventory[IndexOfelements[0]].Fill = new SolidColorBrush(Colors.White);
                    MainWindow.inventoryCondition[IndexOfelements[0]] = "";
                    ImageBrush imgBrush = new ImageBrush();
                    imgBrush.ImageSource = new BitmapImage(new Uri(@"C:\Users\Leon\Desktop\programmDraws\simpleTopor.PNG"));
                    MainWindow.inventory[IndexOfelements[1]].Fill = imgBrush;
                    MainWindow.inventoryCondition[IndexOfelements[1]] = "simpleTopor";
                    i = 15;
                    MainWindow.inventoryCondition = Func.CreateFunc2(MainWindow.inventory, MainWindow.inventoryCondition);
                    MainWindow.indexOfNullInventory = Func.CreateFunc(MainWindow.inventory, MainWindow.indexOfNullInventory, MainWindow.inventory);
                }
            }

        }
    }
}
