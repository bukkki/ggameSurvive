﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace ggame
{
    
    public partial class MainWindow : Window
    {
      
        public MainWindow()
        {
                       
            InitializeComponent();
          
            tabl[0, 0] = r1;    //1
            tabl[0, 1] = r2;    //2
            tabl[0, 2] = r3;    //3
            tabl[0, 3] = r4;    //4
            tabl[0, 4] = r5;    //5
            tabl[1, 0] = r6;    //1
            tabl[1, 1] = r7;    //2
            tabl[1, 2] = r8;    //3
            tabl[1, 3] = r9;    //4
            tabl[1, 4] = r10;   //5
            tabl[2, 0] = r11;   //1
            tabl[2, 1] = r12;   //заполняяяяяяяяяяяяем(2)
            tabl[2, 2] = r13;   //3
            tabl[2, 3] = r14;   //4
            tabl[2, 4] = r15;   //5
            tabl[3, 0] = r16;   //1
            tabl[3, 1] = r17;   //2
            tabl[3, 2] = r18;   //3
            tabl[3, 3] = r19;   //4
            tabl[3, 4] = r20;   //5
            tabl[4, 0] = r21;   //1
            tabl[4, 1] = r22;   //2
            tabl[4, 2] = r23;   //3
            tabl[4, 3] = r24;   //4
            tabl[4, 4] = r25;   //5    
            nowSide[0] = 4;     //координаты старта героя
            nowSide[1] = 2;     //
            inventory[0] = inv1;  //
            inventory[1] = inv2;  //
            inventory[2] = inv3;  //
            inventory[3] = inv4;  //
            inventory[4] = inv5;  //
            inventory[5] = inv6;  //
            inventory[6] = inv7;  //
            inventory[7] = inv8;  //заполняем массив плитками инвенторя
            inventory[8] = inv9;  //
            inventory[9] = inv10; //
            inventory[10] = inv11;//
            inventory[11] = inv12;//
            inventory[12] = inv13;//
            inventory[13] = inv14;//
            inventory[14] = inv15;//
            for (int i = 0; i < 5; i++)//бежим по плиткам-секторам(cтроки)
            {
                for (int a = 0; a < 5; a++)//бежим по плиткам-секторам(cтолбцы)
                {
                    switch (rand.Next(0, 12))//рандом
                    {
                        case 0://рандом 0                       
                            break;
                        case 1://рандом 1                      
                            Func.FillFunc(i, a, nowSide, tabl, condition, new Uri(@"C:\Users\Leon\Desktop\programmDraws\tree.PNG"), "tree");//заполняем деревьями
                            break;
                        case 2://рандом 2                         
                            Func.FillFunc(i, a, nowSide, tabl, condition, new Uri(@"C:\Users\Leon\Desktop\programmDraws\rock.PNG"), "rock");//заполняем камнями                           
                            break;
                        case 3://рандом 3
                            Func.FillFunc(i, a, nowSide, tabl, condition, new Uri(@"C:\Users\Leon\Desktop\programmDraws\lake.PNG"), "lake");//заполняем озёрами
                           break;
                        case 4://рандом 4
                            Func.FillFunc(i, a, nowSide, tabl, condition, new Uri(@"C:\Users\Leon\Desktop\programmDraws\plodTree.PNG"), "plodTree");//заполняем плодовыми деревьями
                            break;
                        case 5://рандом 4
                            Func.FillFunc(i, a, nowSide, tabl, condition, new Uri(@"C:\Users\Leon\Desktop\programmDraws\kremen.PNG"), "kremen");//заполняем плодовыми деревьями
                            break;
                    }
                }                
            }
        }

        public int[] nowSide = new int[2];                          //текущее место героя
        public Rectangle[,] tabl = new Rectangle[5,5];              //массив плиток
        public Random rand = new Random();                          //рандом для заполнения плиток деревьями и др.
        public string[,] condition = new string[5,5];               //массив для хранения состояния плиток, например: "дерево"("tree")
        public static Rectangle[] inventory = new Rectangle[15];    //массив плиток инвертаря
        public static string[] inventoryCondition = new string[15]; //массив хранения состояния плиток инверторя(например: "stick"(палка))
        public static int indexOfNullInventory = 0;                 //переменная для хранения следующей пустой ячейки в инвентаре
        public static Uri myIconSource = new Uri(File.ReadAllText("C:/Users/Leon/source/repos/ggame/ggame/MyIconSource.txt"));
       
        private void GoFront_Click(object sender, RoutedEventArgs e)//вперёд
        {
            try//пробуем, чтобы не выходить за границы поля
            {
                if (condition[nowSide[0] - 1, nowSide[1]] != "tree" && condition[nowSide[0] - 1, nowSide[1]] != "rock" && condition[nowSide[0] - 1, nowSide[1]] != "lake" && condition[nowSide[0] - 1, nowSide[1] ] != "plodTree")// если на плитке, на которою мы шагаем не находится дерево или др.
                {
                    nowSide[0] = nowSide[0] - 1;                                   //задаём новое местоположение героя
                    Func.MooveFunc(tabl, -1, 0, nowSide[0], nowSide[1], condition);//функция движа героя  
                    Func.fatigueFunc(fatigue, golod, jajda, rad, hp);                       //прибавляем усталость, голод, жажду
                }
                else//иначе ищем у объекта
                {                               
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, 1, 0, "tree", new Uri(@"C:\Users\Leon\Desktop\programmDraws\palka.PNG"), fatigue, inventory,"stick", golod, jajda, rad, hp);          //функция запонения инвентаря(палка)
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, 1, 0, "rock", new Uri(@"C:\Users\Leon\Desktop\programmDraws\smallRock.PNG"), fatigue, inventory, "smallRock", golod, jajda, rad, hp); //функция запонения инвентаря(камень)
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, 1, 0, "lake", new Uri(@"C:\Users\Leon\Desktop\programmDraws\water.PNG"), fatigue, inventory, "water", golod, jajda, rad, hp);         //функция запонения инвентаря(вода)
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, 1, 0, "plodTree", new Uri(@"C:\Users\Leon\Desktop\programmDraws\yabloko.PNG"), fatigue, inventory, "yabloko", golod, jajda, rad, hp); //функция запонения инвентаря(яблоко)  
                   
                    inventoryCondition[indexOfNullInventory-1] = File.ReadAllText(@"C: \Users\Leon\Desktop\cond.txt");//читаем состояние из файла
                    Func.fatigueFunc(fatigue, golod, jajda, rad, hp);//прибавляем всякую херню
                }
            }
            catch (Exception)
            {
                //ошибка поймана: fatal Error0000000: егор кандратьев...
            }                                                                  
        }

        private void GoLeft_Click(object sender, RoutedEventArgs e)//лево
        {
            try
            {
                if (condition[nowSide[0] , nowSide[1]- 1] != "tree" && condition[nowSide[0] , nowSide[1] - 1] != "rock" && condition[nowSide[0], nowSide[1] - 1] != "lake" && condition[nowSide[0], nowSide[1] - 1] != "plodTree")// если на плитке, на которою мы шагаем не находится дерево или др.
                {
                    nowSide[1] = nowSide[1] - 1;                                 //задаём новое местоположение героя
                    Func.MooveFunc(tabl, 0, -1, nowSide[0], nowSide[1], condition);//функция движа героя   
                    Func.fatigueFunc(fatigue, golod, jajda, rad, hp);
                }
                else//иначе ищем у объекта
                {
                   
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, 0, 1, "tree", new Uri(@"C:\Users\Leon\Desktop\programmDraws\palka.PNG"), fatigue, inventory, "stick", golod, jajda, rad, hp);         //функция запонения инвентаря(палка)
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, 0, 1, "rock", new Uri(@"C:\Users\Leon\Desktop\programmDraws\smallRock.PNG"), fatigue, inventory, "smallRock", golod, jajda, rad, hp); //функция запонения инвентаря(камень)
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, 0, 1, "lake", new Uri(@"C:\Users\Leon\Desktop\programmDraws\water.PNG"), fatigue, inventory, "water", golod, jajda, rad, hp);         //функция запонения инвентаря(вода)
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, 0, 1, "plodTree", new Uri(@"C:\Users\Leon\Desktop\programmDraws\yabloko.PNG"), fatigue, inventory, "yabloko", golod, jajda, rad, hp);         //функция запонения инвентаря(вода)
                   
                    inventoryCondition[indexOfNullInventory - 1] = File.ReadAllText(@"C: \Users\Leon\Desktop\cond.txt");//читаем состояние из файла
                    Func.fatigueFunc(fatigue, golod, jajda, rad, hp);
                }
            }
            catch (Exception)
            {
                //ничего
            }
        }

        private void GoBack_Click(object sender, RoutedEventArgs e)//назад
        {
            try
            {
                if (condition[nowSide[0] + 1, nowSide[1]] != "tree" && condition[nowSide[0] + 1, nowSide[1]] != "rock" && condition[nowSide[0] + 1, nowSide[1]] != "lake" && condition[nowSide[0] + 1, nowSide[1]] != "plodTree")// если на плитке, на которою мы шагаем не находится дерево или др.
                {
                    nowSide[0] = nowSide[0] + 1;//задаём новое местоположение героя
                    Func.MooveFunc(tabl, 1, 0, nowSide[0], nowSide[1], condition);
                    Func.fatigueFunc(fatigue, golod, jajda, rad, hp);
                }
                else
                {            
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, -1, 0, "tree", new Uri(@"C:\Users\Leon\Desktop\programmDraws\palka.PNG"), fatigue, inventory, "stick", golod, jajda, rad, hp);
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, -1, 0, "rock", new Uri(@"C:\Users\Leon\Desktop\programmDraws\smallRock.PNG"), fatigue, inventory, "smallRock", golod, jajda, rad, hp);
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, -1, 0, "lake", new Uri(@"C:\Users\Leon\Desktop\programmDraws\water.PNG"), fatigue, inventory, "water", golod, jajda, rad, hp);
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, -1, 0, "plodTree", new Uri(@"C:\Users\Leon\Desktop\programmDraws\yabloko.PNG"), fatigue, inventory, "yabloko", golod, jajda, rad, hp);         //функция запонения инвентаря(вода)
                 

                    inventoryCondition[indexOfNullInventory - 1] = File.ReadAllText(@"C: \Users\Leon\Desktop\cond.txt");//читаем состояние из файла
                    Func.fatigueFunc(fatigue, golod, jajda, rad, hp);
                }
            }
            catch (Exception)
            {

            }
        }

        private void GoRight_Click(object sender, RoutedEventArgs e)//право
        {
            try
            {
                if (condition[nowSide[0], nowSide[1] + 1] != "tree" && condition[nowSide[0] , nowSide[1] + 1] != "rock" && condition[nowSide[0], nowSide[1] + 1] != "lake" && condition[nowSide[0], nowSide[1] + 1] != "plodTree")// если на плитке, на которою мы шагаем не находится дерево
                {
                    nowSide[1] = nowSide[1] + 1;//задаём новое местоположение героя
                    Func.MooveFunc(tabl, 0, 1, nowSide[0], nowSide[1],  condition);
                    Func.fatigueFunc(fatigue, golod, jajda, rad, hp);
                }
                else
                {
                   
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, 0, -1, "tree", new Uri(@"C:\Users\Leon\Desktop\programmDraws\palka.PNG"), fatigue, inventory, "stick", golod, jajda, rad, hp);
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, 0, -1, "rock", new Uri(@"C:\Users\Leon\Desktop\programmDraws\smallRock.PNG"), fatigue, inventory, "smallRock", golod, jajda, rad, hp);
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, 0, -1, "lake", new Uri(@"C:\Users\Leon\Desktop\programmDraws\water.PNG"), fatigue, inventory, "water", golod, jajda, rad, hp);
                    indexOfNullInventory = Func.InvFunc(indexOfNullInventory, inventoryCondition, condition, nowSide, 0, -1, "plodTree", new Uri(@"C:\Users\Leon\Desktop\programmDraws\yabloko.PNG"), fatigue, inventory, "yabloko", golod, jajda, rad, hp);         //функция запонения инвентаря(вода)
                  

                    inventoryCondition[indexOfNullInventory - 1] = File.ReadAllText(@"C: \Users\Leon\Desktop\cond.txt");//читаем состояние из файла
                    Func.fatigueFunc(fatigue, golod, jajda, rad, hp);
                }
            } 
            catch (Exception)
            {
           //         /\
           //        //\\
           //       //  \\
           //      //    \\
           //     // //\\ \\
           //    //  \\//  \\
           //   //   //\\   \\
           //  //    \\//    \\
           //  ////////////////
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)//создание
        {
            create cr = new create(); //показываем окно создания
            cr.Show();                //
        }

        private void R18_click(object sender, MouseButtonEventArgs e)//если кликнуть на плитку
        {
            Func.RubFunc(inventoryCondition, r18, fatigue, 3, 2, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
            inventoryCondition = Func.FuncOfPoleSerch(3, 2, nowSide, "kremen", "smallkremen", condition, tabl, r18, indexOfNullInventory, inventoryCondition, inventory, new Uri(@"C:\Users\Leon\Desktop\programmDraws\smallKremen.png"));
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void R1_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r1, fatigue, 0, 0, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
            inventoryCondition = Func.FuncOfPoleSerch(0, 0, nowSide, "kremen", "smallkremen", condition, tabl, r1, indexOfNullInventory, inventoryCondition, inventory, new Uri(@"C:\Users\Leon\Desktop\programmDraws\smallKremen.png"));
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void R2_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r2, fatigue, 0, 1, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R3_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r3, fatigue, 0, 2, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }
        
        private void R4_cick(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r4, fatigue, 0, 3, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R5_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r5, fatigue, 0, 4, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }
            private void R6_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r6, fatigue, 1, 0, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R7_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r7, fatigue, 1, 1, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьевv
        }

        private void R8_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r8, fatigue, 1, 2, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R9_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r9, fatigue, 1, 3, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R10_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r10, fatigue, 1, 4, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R11_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r11, fatigue, 2, 0, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R12_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r12, fatigue, 2, 1, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R13_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r13, fatigue, 2, 2, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R14_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r14, fatigue, 2, 3, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }
        private void R15_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r15, fatigue, 2, 4, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R16_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r16, fatigue, 3, 0, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }
        private void R17_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r17, fatigue, 3, 1, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R19_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r19, fatigue, 3, 3, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R20_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r20, fatigue, 3, 4, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R21_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r21, fatigue, 4, 0, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R22_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r22, fatigue, 4, 1, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R24_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r24, fatigue, 4, 3, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R25_click(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r25, fatigue, 4, 4, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R13_clic(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r13, fatigue, 0, 0, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьев
        }

        private void R14_clicki(object sender, MouseButtonEventArgs e)
        {
            Func.RubFunc(inventoryCondition, r14, fatigue, 0, 0, condition, nowSide[0], nowSide[1], tabl);//функция рубки деревьевv
        }

        private void Inv1_click(object sender, MouseButtonEventArgs e)//кликаем левой кнопкой
        {
           inventoryCondition = Func.InvClick(inventoryCondition, 0, inv1, inventory, indexOfNullInventory, jajda, golod, rad, hp);//функция использования предметов из инвентаря, например: попить воды
           indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));             //читаем новый индекс свободной плитки       
        }

        private void Inv2_click(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvClick(inventoryCondition, 1, inv2, inventory, indexOfNullInventory, jajda, golod, rad, hp);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv3_click(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvClick(inventoryCondition, 2, inv3, inventory, indexOfNullInventory, jajda, golod, rad, hp);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv4_click(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvClick(inventoryCondition, 3, inv4, inventory, indexOfNullInventory, jajda, golod, rad, hp);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv5_click(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvClick(inventoryCondition, 4, inv5, inventory, indexOfNullInventory, jajda, golod, rad, hp);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv6_click(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvClick(inventoryCondition, 5, inv6, inventory, indexOfNullInventory, jajda, golod, rad, hp);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv7_click(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvClick(inventoryCondition, 6, inv7, inventory, indexOfNullInventory, jajda, golod, rad, hp);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv8_click(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvClick(inventoryCondition, 7, inv8, inventory, indexOfNullInventory, jajda, golod, rad, hp);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv9_click(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvClick(inventoryCondition, 8, inv9, inventory, indexOfNullInventory, jajda, golod, rad, hp);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv10_click(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvClick(inventoryCondition, 9, inv10, inventory, indexOfNullInventory, jajda, golod, rad, hp);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv11_click(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvClick(inventoryCondition, 10, inv11, inventory, indexOfNullInventory, jajda, golod, rad, hp);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv12_click(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvClick(inventoryCondition, 11, inv12, inventory, indexOfNullInventory, jajda, golod, rad, hp);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv13_click(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvClick(inventoryCondition, 12, inv13, inventory, indexOfNullInventory, jajda, golod, rad, hp);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv14_click(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvClick(inventoryCondition, 13, inv14, inventory, indexOfNullInventory, jajda, golod, rad, hp);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv15_click(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvClick(inventoryCondition, 14, inv15, inventory, indexOfNullInventory, jajda, golod, rad, hp);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv1_deleteClick(object sender, MouseButtonEventArgs e)//кликаем правой кнопкой
        {
          inventoryCondition = Func.InvDelete(inventoryCondition, 0, inv1, inventory, indexOfNullInventory);//метод удаления из инвентаря
          indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));//читаем новый индекс свободной плитки   
        }

        private void Inv2_deleteClick(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvDelete(inventoryCondition, 1, inv2, inventory, indexOfNullInventory);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv3_deleteClick(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvDelete(inventoryCondition, 2, inv3, inventory, indexOfNullInventory);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv4_deleteClick(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvDelete(inventoryCondition, 3, inv4, inventory, indexOfNullInventory);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv5_deleteClick(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvDelete(inventoryCondition, 4, inv5, inventory, indexOfNullInventory);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv6_deleteClick(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvDelete(inventoryCondition, 5, inv6, inventory, indexOfNullInventory);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv7_deleteClick(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvDelete(inventoryCondition, 6, inv7, inventory, indexOfNullInventory);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv8_deleteClick(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvDelete(inventoryCondition, 7, inv8, inventory, indexOfNullInventory);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv9_deleteClick(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvDelete(inventoryCondition, 8, inv9, inventory, indexOfNullInventory);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv10_deleteClick(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvDelete(inventoryCondition, 9, inv10, inventory, indexOfNullInventory);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv12_deleteClick(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvDelete(inventoryCondition, 11, inv12, inventory, indexOfNullInventory);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv11_deleteClick(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvDelete(inventoryCondition, 10, inv11, inventory, indexOfNullInventory);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv13_deleteClick(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvDelete(inventoryCondition, 12, inv13, inventory, indexOfNullInventory);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv14_deleteClick(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvDelete(inventoryCondition, 13, inv14, inventory, indexOfNullInventory);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Inv15_deleteClick(object sender, MouseButtonEventArgs e)
        {
            inventoryCondition = Func.InvDelete(inventoryCondition, 14, inv15, inventory, indexOfNullInventory);
            indexOfNullInventory = Convert.ToInt32(File.ReadAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt"));
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {       
            if (MessageBox.Show("вы действителрно хотите выйти из игры?", "Exit", MessageBoxButton.YesNo, MessageBoxImage.Question).ToString() == "Yes")
            {
                Environment.Exit(0);
                File.WriteAllText(@"C:\Users\Leon\Desktop\cond.txt", "");
                File.WriteAllText(@"C:\Users\Leon\Desktop\indexOfNul.txt", "");
            }          
        }

        private void Load_Click(object sender, RoutedEventArgs e)
        {
            Window1 Load = new Window1();
            Load.Show();
        }

        private void Sleep_Click(object sender, RoutedEventArgs e)
        {
            fatigue.Value -= 10;
            rad.Value += 2;
            golod.Value += 2;
            jajda.Value += 2;
        }
    }
}
